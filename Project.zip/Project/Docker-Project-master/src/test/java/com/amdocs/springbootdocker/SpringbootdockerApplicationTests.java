package com.amdocs.springbootdocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootdockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
