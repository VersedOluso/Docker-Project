package com.amdocs.SeliniumProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeliniumProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeliniumProjectApplication.class, args);
	}

}
