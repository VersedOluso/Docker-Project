package com.amdocs.SeliniumProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeliniumProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
